-- Adminer 4.2.5 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `tbartista`;
CREATE TABLE `tbartista` (
  `cdArtista` int(11) NOT NULL AUTO_INCREMENT,
  `stNome` varchar(45) NOT NULL,
  PRIMARY KEY (`cdArtista`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tbartista` (`cdArtista`, `stNome`) VALUES
(1,	'Raimundos'),
(2,	'Capital Inicial'),
(3,	'Charlie Brown Jr'),
(4,	'Os Paralamos do Sucesso'),
(5,	'Engenheiros do Hawai'),
(6,	'O Rappa'),
(7,	'Legião Urbana'),
(8,	'Guns N\' Roses'),
(9,	'Creedance'),
(10,	'Eagles'),
(11,	'Tihuana'),
(12,	'Foo Fighters'),
(13,	'Nenhum de nós'),
(14,	'Metalica'),
(15,	'Oasis'),
(16,	'REM'),
(17,	'Titãs'),
(18,	'Steppenwolf'),
(19,	'Led zeppelin'),
(20,	'Pink Floyd'),
(21,	'AC/DC'),
(22,	'Raul'),
(23,	'Lynyrd Skynyrd'),
(24,	'Nirvana'),
(25,	'Bon Jovi'),
(26,	'Deep purple'),
(27,	'Kiss');

DROP TABLE IF EXISTS `tbgenero`;
CREATE TABLE `tbgenero` (
  `cdGenero` int(11) NOT NULL AUTO_INCREMENT,
  `stNome` varchar(45) NOT NULL,
  PRIMARY KEY (`cdGenero`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tbgenero` (`cdGenero`, `stNome`) VALUES
(1,	'Pop/Rock');

DROP TABLE IF EXISTS `tbinstrumento`;
CREATE TABLE `tbinstrumento` (
  `cdInstrumento` int(11) NOT NULL AUTO_INCREMENT,
  `stNome` varchar(45) NOT NULL,
  PRIMARY KEY (`cdInstrumento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `tbinstrumentoitem`;
CREATE TABLE `tbinstrumentoitem` (
  `cdInstrumento` int(11) NOT NULL,
  `cdMusicaArtista` int(11) NOT NULL,
  `stObservacao` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`cdInstrumento`,`cdMusicaArtista`),
  KEY `fk_tbinstrumento_has_tbmusicaartista_tbmusicaartista1_idx` (`cdMusicaArtista`),
  KEY `fk_tbinstrumento_has_tbmusicaartista_tbinstrumento1_idx` (`cdInstrumento`),
  CONSTRAINT `fk_tbinstrumento_has_tbmusicaartista_tbinstrumento1` FOREIGN KEY (`cdInstrumento`) REFERENCES `tbinstrumento` (`cdInstrumento`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_tbinstrumento_has_tbmusicaartista_tbmusicaartista1` FOREIGN KEY (`cdMusicaArtista`) REFERENCES `tbmusicaartista` (`cdMusicaArtista`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `tbmusica`;
CREATE TABLE `tbmusica` (
  `cdMusica` int(11) NOT NULL AUTO_INCREMENT,
  `stNome` varchar(45) NOT NULL,
  PRIMARY KEY (`cdMusica`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tbmusica` (`cdMusica`, `stNome`) VALUES
(31,	'À Sua Maneira'),
(32,	'Mulher de fases'),
(33,	'A mais pedida'),
(34,	'Aquela'),
(35,	'I Saw You Saying'),
(36,	'Me encontra'),
(37,	'Papo reto'),
(38,	'Vem ser minha'),
(39,	'Proibida pra mim'),
(40,	'Fátima'),
(41,	'Meu erro'),
(42,	'Vital e sua moto'),
(43,	'O Papa é pop'),
(44,	'Anjos'),
(45,	'Pescador de ilusões'),
(46,	'Que país é esse'),
(47,	'Tempo perdido'),
(48,	'Pais e filhos'),
(49,	'Será'),
(50,	'Há tempos'),
(51,	'Sweet Child\'o mine'),
(52,	'Knockin\' on Heaven\'s Door'),
(53,	'Have you ever seen the rain'),
(54,	'Hotel Califórnia'),
(55,	'Que vez'),
(56,	'Times Like these'),
(57,	'O Astronalta de Mármore'),
(58,	'Nothing Else Mathers'),
(59,	'Wonderwall '),
(60,	'Losing my religion'),
(61,	'Marvin'),
(62,	'Born to be wild'),
(63,	'Stairway to heaven'),
(64,	'Wish you were here'),
(65,	'Highway to hell'),
(66,	'Back in Black'),
(67,	'Maluco Beleza'),
(68,	'Aluga-se'),
(69,	'Simple man'),
(70,	'Smells Like Teen Spirit'),
(71,	'Wanted Dead Or Alive'),
(72,	'Its my life'),
(73,	'Smoke on the water'),
(74,	'I Wanna Rock n Roll All Nigtht');

DROP TABLE IF EXISTS `tbmusicaartista`;
CREATE TABLE `tbmusicaartista` (
  `cdMusicaArtista` int(11) NOT NULL AUTO_INCREMENT,
  `cdArtista` int(11) NOT NULL,
  `cdMusica` int(11) NOT NULL,
  `cdGenero` int(11) NOT NULL,
  `stLinkVideo` varchar(255) DEFAULT NULL,
  `stTom` varchar(20) DEFAULT NULL,
  `dtCadastro` timestamp NULL DEFAULT NULL,
  `dtAlteracao` timestamp NULL DEFAULT NULL,
  `stLinkCifra` varchar(255) DEFAULT NULL,
  `stTempoDuracao` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`cdMusicaArtista`,`cdArtista`,`cdMusica`),
  UNIQUE KEY `cdArtista_cdGenero_cdMusica` (`cdArtista`,`cdGenero`,`cdMusica`),
  KEY `fk_tbartista_has_tbmusica_tbmusica1_idx` (`cdMusica`),
  KEY `fk_tbartista_has_tbmusica_tbartista1_idx` (`cdArtista`),
  KEY `cdGenero` (`cdGenero`),
  CONSTRAINT `fk_tbartista_has_tbmusica_tbartista1` FOREIGN KEY (`cdArtista`) REFERENCES `tbartista` (`cdArtista`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_tbartista_has_tbmusica_tbmusica1` FOREIGN KEY (`cdMusica`) REFERENCES `tbmusica` (`cdMusica`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `tbmusicaartista_ibfk_1` FOREIGN KEY (`cdGenero`) REFERENCES `tbgenero` (`cdGenero`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tbmusicaartista` (`cdMusicaArtista`, `cdArtista`, `cdMusica`, `cdGenero`, `stLinkVideo`, `stTom`, `dtCadastro`, `dtAlteracao`, `stLinkCifra`, `stTempoDuracao`) VALUES
(4,	2,	31,	1,	'https://www.cifraclub.com.br/capital-inicial/a-sua-maneira/',	'D',	NULL,	NULL,	'https://www.cifraclub.com.br/capital-inicial/a-sua-maneira/',	'4:18'),
(5,	1,	32,	1,	'https://www.cifraclub.com.br/raimundos/mulher-de-fases/',	'G',	NULL,	NULL,	'https://www.cifraclub.com.br/raimundos/mulher-de-fases/',	'3:29'),
(93,	1,	33,	1,	NULL,	'C',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/raimundos/a-mais-pedida/',	NULL),
(94,	1,	34,	1,	NULL,	'E',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/raimundos/aquela/',	NULL),
(95,	1,	35,	1,	NULL,	'A',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/raimundos/i-saw-you-saying-that-you-say-that-you-saw/',	NULL),
(96,	3,	36,	1,	NULL,	'C Capo 3',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/charlie-brown-jr/me-encontra/',	NULL),
(97,	3,	37,	1,	NULL,	'F#',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/charlie-brown-jr/papo-reto/',	'3:37'),
(98,	3,	38,	1,	NULL,	'Cm',	'2016-09-03 23:52:32',	NULL,	'http://www.cifras.com.br/cifra/charlie-brown-jr/vem-ser-minha',	NULL),
(99,	3,	39,	1,	NULL,	'D#',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/charlie-brown-jr/proibida-pra-mim/',	NULL),
(100,	2,	40,	1,	NULL,	'D#',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/capital-inicial/fatima/',	'3:51'),
(101,	4,	41,	1,	NULL,	'C',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/os-paralamas-do-sucesso/meu-erro/',	'3:06'),
(102,	4,	42,	1,	NULL,	'A',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/os-paralamas-do-sucesso/vital-sua-moto/',	NULL),
(103,	5,	43,	1,	NULL,	'G',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/engenheiros-do-hawaii/o-papa-e-pop-acustico-mtv/',	'3:22'),
(104,	6,	44,	1,	NULL,	'F#',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/o-rappa/anjos/',	'6:59'),
(105,	6,	45,	1,	NULL,	'C',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/o-rappa/pescador-de-ilusoes/',	'4:18'),
(106,	7,	46,	1,	NULL,	'G',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/legiao-urbana/que-pais-e-esse/',	'3:01'),
(107,	7,	47,	1,	NULL,	'G',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/legiao-urbana/tempo-perdido/',	'3:52'),
(108,	7,	48,	1,	NULL,	'G',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/legiao-urbana/pais-filhos/',	'5:10'),
(109,	7,	49,	1,	NULL,	'C',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/legiao-urbana/sera/',	NULL),
(110,	7,	50,	1,	NULL,	'D',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/legiao-urbana/ha-tempos/',	'3:19'),
(111,	8,	51,	1,	NULL,	'D',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/guns-n-roses/sweet-child-omine/',	'5:00'),
(112,	8,	52,	1,	NULL,	'G',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/guns-n-roses/knocking-on-heavens-door/',	'5:42'),
(113,	9,	53,	1,	NULL,	'C',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/creedence-clearwater-revival/have-you-ever-seen-the-rain/',	'2:42'),
(114,	10,	54,	1,	NULL,	'C',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/the-eagles/hotel-california/',	'6:26'),
(115,	11,	55,	1,	NULL,	'C',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/tihuana/que-ves/',	'3:27'),
(116,	12,	56,	1,	NULL,	'D',	'2016-09-03 23:52:32',	NULL,	'https://www.youtube.com/watch?v=2w0JiLKQ3-o',	'3:59'),
(117,	13,	57,	1,	NULL,	'F',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/nenhum-de-nos/o-astronauta-de-marmore/',	'3:17'),
(118,	14,	58,	1,	NULL,	'G',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/metallica/nothing-else-matters/',	'6:26'),
(119,	15,	59,	1,	NULL,	'G',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/oasis/wonderwall/',	'4:37'),
(120,	16,	60,	1,	NULL,	'C Capo 5',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/rem/losing-my-religion/',	'4:46'),
(121,	17,	61,	1,	NULL,	'B',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/titas/marvin/',	'4:40'),
(122,	18,	62,	1,	NULL,	'E',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/steppenwolf/born-to-be-wild/',	'3:31'),
(123,	19,	63,	1,	NULL,	'C',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/led-zeppelin/stairway-to-heaven/',	'7:58'),
(124,	20,	64,	1,	NULL,	'G',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/pink-floyd/wish-you-were-here/',	'5:41'),
(125,	21,	65,	1,	NULL,	'D',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/ac-dc/highway-to-hell/',	'3:28'),
(126,	21,	66,	1,	NULL,	'A',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/ac-dc/back-in-black/',	'4:14'),
(127,	22,	67,	1,	NULL,	'C',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/raul-seixas/maluco-beleza/',	'3:28'),
(128,	22,	68,	1,	NULL,	'C',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/titas/aluga-se/',	'3:21'),
(129,	23,	69,	1,	NULL,	'C',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/lynyrd-skynyrd/simple-man/',	'5:51'),
(130,	24,	70,	1,	NULL,	'C#',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/nirvana/smells-like-teen-spirit/',	'4:38'),
(131,	25,	71,	1,	NULL,	'C',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/bon-jovi/dead-or-alive/',	'4:10'),
(132,	25,	72,	1,	NULL,	'D',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/bon-jovi/its-my-life/',	'4:28'),
(133,	26,	73,	1,	NULL,	'F',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/deep-purple/smoke-on-the-water/#autoplay=true',	'5:41'),
(134,	27,	74,	1,	NULL,	'A#',	'2016-09-03 23:52:32',	NULL,	'https://www.cifraclub.com.br/kiss/rock-and-roll-all-nite/',	'4:01');

DROP TABLE IF EXISTS `tbsetlist`;
CREATE TABLE `tbsetlist` (
  `cdSetlist` int(11) NOT NULL AUTO_INCREMENT,
  `stNome` varchar(45) NOT NULL,
  `dtCadastro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `inNota` int(2) DEFAULT NULL,
  PRIMARY KEY (`cdSetlist`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tbsetlist` (`cdSetlist`, `stNome`, `dtCadastro`, `inNota`) VALUES
(1,	'Rock In Rio Ivaí',	'2016-08-13 17:29:11',	NULL),
(2,	'Ensaios padrão',	'2016-08-20 14:55:01',	NULL);

DROP TABLE IF EXISTS `tbsetlistitem`;
CREATE TABLE `tbsetlistitem` (
  `cdSetlist` int(11) NOT NULL,
  `cdMusicaArtista` int(11) NOT NULL,
  `dtCadastro` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`cdSetlist`,`cdMusicaArtista`),
  KEY `fk_tbsetlist_has_tbmusicaartista_tbmusicaartista1_idx` (`cdMusicaArtista`),
  KEY `fk_tbsetlist_has_tbmusicaartista_tbsetlist1_idx` (`cdSetlist`),
  CONSTRAINT `fk_tbsetlist_has_tbmusicaartista_tbmusicaartista1` FOREIGN KEY (`cdMusicaArtista`) REFERENCES `tbmusicaartista` (`cdMusicaArtista`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_tbsetlist_has_tbmusicaartista_tbsetlist1` FOREIGN KEY (`cdSetlist`) REFERENCES `tbsetlist` (`cdSetlist`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tbsetlistitem` (`cdSetlist`, `cdMusicaArtista`, `dtCadastro`) VALUES
(1,	4,	'2016-09-04 00:56:03'),
(1,	5,	'2016-09-03 23:55:27'),
(1,	93,	'2016-09-04 00:56:03'),
(1,	94,	'2016-09-04 00:56:03'),
(1,	95,	'2016-09-04 00:56:03'),
(1,	96,	'2016-09-04 00:56:03'),
(1,	97,	'2016-09-04 00:56:03'),
(1,	98,	'2016-09-04 00:56:03'),
(1,	99,	'2016-09-04 00:56:03'),
(1,	100,	'2016-09-04 00:56:03'),
(1,	101,	'2016-09-04 01:24:19'),
(1,	102,	'2016-09-04 00:56:03'),
(1,	103,	'2016-09-04 00:56:03'),
(1,	104,	'2016-09-04 00:56:03'),
(1,	105,	'2016-09-04 00:56:03'),
(1,	106,	'2016-09-04 00:56:03'),
(1,	107,	'2016-09-04 00:59:10'),
(1,	108,	'2016-09-04 00:56:03'),
(1,	109,	'2016-09-04 00:56:03'),
(1,	110,	'2016-09-04 00:56:03'),
(1,	111,	'2016-09-04 00:59:10'),
(1,	112,	'2016-09-04 00:56:03'),
(1,	113,	'2016-09-04 00:56:03'),
(1,	114,	'2016-09-04 00:56:03'),
(1,	116,	'2016-09-04 00:59:10'),
(1,	117,	'2016-09-04 00:56:03'),
(1,	118,	'2016-09-04 00:56:03'),
(1,	119,	'2016-09-04 00:56:03'),
(1,	120,	'2016-09-04 00:59:10'),
(1,	121,	'2016-09-04 00:56:03'),
(1,	122,	'2016-09-04 00:59:10'),
(1,	123,	'2016-09-04 00:56:03'),
(1,	124,	'2016-09-04 00:59:10'),
(1,	125,	'2016-09-04 00:56:03'),
(1,	127,	'2016-09-04 00:56:03'),
(1,	128,	'2016-09-04 00:56:03'),
(1,	129,	'2016-09-04 00:56:03'),
(1,	130,	'2016-09-04 00:59:10'),
(1,	132,	'2016-09-04 00:59:10'),
(1,	133,	'2016-09-04 00:56:03');

DROP TABLE IF EXISTS `tbuser`;
CREATE TABLE `tbuser` (
  `cdUser` int(11) NOT NULL AUTO_INCREMENT,
  `stLogin` varchar(45) NOT NULL,
  `stSenha` varchar(45) NOT NULL,
  `stNome` varchar(80) NOT NULL,
  PRIMARY KEY (`cdUser`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- 2016-09-04 01:33:40
